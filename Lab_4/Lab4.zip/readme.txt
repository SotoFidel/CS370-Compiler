Name: Fidel Soto
Project Name: Lab4
Requirements Completed: All requirements have been fulfilled. Now, when lab4 runs,
                        If more variables are declared than the program allows,
                        the program will throw an error, and the variable will not
                        have been officially declared. Also, the program will check
                        that no variable is declared more than once. If it is declared
                        more than once, the program will throw an error message, 
                        but it won't exit. In addition, the program will check for undeclared
                        variables by using the search function in symtable.c. If the symbol is
                        found, then its address will be returned, and the address will be passed
                        on as the index of regs[]. Otherwise, an error will be thrown. Finally,
                        Variables can be set, and they can also be used in the right hand side
                        of expressions.
